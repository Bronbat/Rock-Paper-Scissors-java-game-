import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RockPaperScissorsGame extends JPanel {
    private JTextField player1NameTextField;
    private JTextField player2NameTextField;
    private JLabel roundNumberLabel;
    private JRadioButton[] roundNumberButtons;
    private JButton startButton;

    private String player1Name;
    private String player2Name;
    private int totalRounds;

    public RockPaperScissorsGame() {
        setLayout(new BorderLayout());


        JPanel inputPanel = createInputPanel();
        JPanel playPanel = createPlayPanel();


        add(inputPanel, BorderLayout.NORTH);
        add(playPanel, BorderLayout.CENTER);
    }

    private JPanel createInputPanel() {
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4, 2));

        JLabel player1NameLabel = new JLabel("Oyuncu 1 İsim: ");
        player1NameTextField = new JTextField(15);

        JLabel player2NameLabel = new JLabel("Oyuncu 2 İsim: ");
        player2NameTextField = new JTextField(15);

        roundNumberLabel = new JLabel("Tur seçimi yap (1-10): ");
        JPanel roundNumberPanel = createRoundNumberPanel();

        startButton = new JButton("Başlat");


        inputPanel.add(player1NameLabel);
        inputPanel.add(player1NameTextField);
        inputPanel.add(player2NameLabel);
        inputPanel.add(player2NameTextField);
        inputPanel.add(roundNumberLabel);
        inputPanel.add(roundNumberPanel);
        inputPanel.add(startButton);


        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                getPlayerNames();
                getRoundNumber();
                playGame();
            }
        });

        return inputPanel;
    }

    private void playGame() {
    }

    private JPanel createRoundNumberPanel() {
        JPanel roundNumberPanel = new JPanel();
        roundNumberButtons = new JRadioButton[10];

        ButtonGroup buttonGroup = new ButtonGroup();
        for (int i = 0; i < roundNumberButtons.length; i++) {
            roundNumberButtons[i] = new JRadioButton(Integer.toString(i + 1));
            buttonGroup.add(roundNumberButtons[i]);
            roundNumberPanel.add(roundNumberButtons[i]);
        }

        roundNumberButtons[0].setSelected(true); // Default selection

        return roundNumberPanel;
    }

    private JPanel createPlayPanel() {
        JPanel playPanel = new JPanel();
        playPanel.setLayout(new GridLayout(1, 2));

        JPanel player1Panel = createPlayerPanel("oyuncu 1");
        JPanel player2Panel = createPlayerPanel("oyuncu 2");

        playPanel.add(player1Panel);
        playPanel.add(player2Panel);

        return playPanel;
    }

    private JPanel createPlayerPanel(String playerName) {
        JPanel playerPanel = new JPanel();
        playerPanel.setLayout(new BorderLayout());

        JLabel nameLabel = new JLabel(playerName);
        JButton rockButton = createChoiceButton(playerName, "taş");
        JButton paperButton = createChoiceButton(playerName, "kağıt");
        JButton scissorsButton = createChoiceButton(playerName, "makas");

        playerPanel.add(nameLabel, BorderLayout.NORTH);
        playerPanel.add(rockButton, BorderLayout.WEST);
        playerPanel.add(paperButton, BorderLayout.CENTER);
        playerPanel.add(scissorsButton, BorderLayout.EAST);

        return playerPanel;
    }

    private JButton createChoiceButton(String playerName, String choice) {
        JButton button = new JButton(choice);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String result = playerName + " seçim: " + choice;
                JOptionPane.showMessageDialog(null, result, "seçim", JOptionPane.INFORMATION_MESSAGE);
                playRound(playerName, choice);
            }
        });
        return button;
    }

    private void getPlayerNames() {
        player1Name = player1NameTextField.getText();
        player2Name = player2NameTextField.getText();
    }

    private void getRoundNumber() {
        for (int i = 0; i < roundNumberButtons.length; i++) {
            if (roundNumberButtons[i].isSelected()) {
                totalRounds = i + 1;
                break;
            }
        }
    }

    private void playRound(String playerName, String choice) {
        String otherPlayerName = (playerName.equals("Oyuncu 2")) ? "Oyuncu 2" : "Oyuncu 2";

        String otherPlayerChoice = getPlayerChoice(otherPlayerName);
        String roundResult = determineRoundResult(playerName, choice, otherPlayerName, otherPlayerChoice);

        JOptionPane.showMessageDialog(null, "Tur sonucu:\n" + roundResult, "Tur sonucu", JOptionPane.INFORMATION_MESSAGE);
    }

    private String getPlayerChoice(String playerName) {
        String choice = "";
        boolean validChoice = false;

        while (!validChoice) {
            choice = JOptionPane.showInputDialog(null, playerName + ", seçimini gir(taş kağıt makas):");
            if (choice != null && (choice.equals("taş") || choice.equals("kağıt") || choice.equals("makas"))) {
                validChoice = true;
            } else {
                JOptionPane.showMessageDialog(null, "Uygunsuz seçim", "Geçersiz seçim", JOptionPane.WARNING_MESSAGE);
            }
        }

        return choice;
    }

    private String determineRoundResult(String player1Name, String player1Choice, String player2Name, String player2Choice) {
        if (player1Choice.equals(player2Choice)) {
            return "Berabere!";
        } else if ((player1Choice.equals("taş") && player2Choice.equals("makas")) ||
                (player1Choice.equals("makas") && player2Choice.equals("kağıt")) ||
                (player1Choice.equals("kağıt") && player2Choice.equals("taş"))) {
            return player1Name + " Kazanır";
        } else {
            return player2Name + " Kazanır";
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("TAŞ KAĞIT MAKAS OYUNU");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(600, 400);
                frame.setLocationRelativeTo(null);

                RockPaperScissorsGame gamePanel = new RockPaperScissorsGame();
                frame.getContentPane().add(gamePanel);

                frame.setVisible(true);
            }
        });
    }
}
